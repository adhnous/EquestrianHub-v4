// src/store/authStore.js
import { create } from 'zustand';
import { login as apiLogin, logout as apiLogout } from '../services/authApi'; // Correct imports from authApi.js
import { getStoredAuthToken } from '../services/api'; // Import getStoredAuthToken separately from api.js

// Try to get existing auth data with error handling for malformed localStorage data
const storedToken = getStoredAuthToken(); // Using the imported getStoredAuthToken
const storedUser = (() => {
  try {
    const userData = localStorage.getItem('user');
    return userData ? JSON.parse(userData) : null;
  } catch (error) {
    console.error('Failed to parse stored user from localStorage:', error); // Log parsing error
    return null;
  }
})();

const useAuthStore = create((set) => ({
  user: storedUser,
  token: storedToken || null,
  isAuthenticated: !!(storedToken && storedUser),
  isLoading: false,
  error: null,

  /**
   * Logs in a user with the given credentials.
   *
   * @param {Object} credentials - Object with 'username' and 'password' properties.
   * @returns {Promise<Object>} - Resolves with the response data from the server.
   */
  login: async (credentials) => {
    set({ isLoading: true, error: null });
    console.log('Login attempt started with credentials:', credentials); // Log login attempt
    try {
      const response = await apiLogin(credentials); // Call apiLogin function
      console.log('Full Response:', response); // Log the full Axios response object
      console.log('API Response Data:', response.data); // Log the response.data object

      // Validate response structure
      if (!response?.data?.success || !response?.data?.token || !response?.data?.user) {
        console.error('Invalid response structure:', response?.data); // Log invalid response structure
        throw new Error('Invalid response structure from server');
      }

      const { success, token, user } = response.data;

      // Validate parsed data
      console.log('Parsed Response Data:', { success, token, user }); // Log parsed data
      if (!success || !token || !user) {
        console.error('Invalid parsed data:', { success, token, user }); // Log the parsed data
        throw new Error('Invalid response structure from server');
      }

      // Save user data to local storage
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
      console.log('Token and user saved to localStorage:', { token, user }); // Log stored data

      // Update Zustand state
      set({
        user,
        token,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });

      console.log('Login successful. State updated.'); // Log successful state update
      return response.data;
    } catch (error) {
      console.error('Login error:', error); // Log the error details

      // Remove user data from local storage
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      console.log('Cleared token and user from localStorage due to login error.'); // Log clear action

      // Reset Zustand state
      set({
        user: null,
        token: null,
        isAuthenticated: false,
        isLoading: false,
        error: error.message || 'An error occurred during login',
      });

      throw error; // Re-throw error for the caller
    }
  },

  /**
   * Logs out the user by clearing the state and localStorage.
   * @returns {Promise<void>}
   */
  logout: async () => {
    console.log('Logging out user...'); // Log logout attempt
    try {
      await apiLogout(); // Wait for apiLogout to complete
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      console.log('Cleared token and user from localStorage during logout.'); // Log cleared data

      set({
        user: null,
        token: null,
        isAuthenticated: false,
        error: null,
      });
      console.log('User logged out. State reset.'); // Log state reset
    } catch (error) {
      console.error('Logout error:', error);
      throw error;
    }
  },

  /**
   * Clears any stored error in the state.
   */
  clearError: () => {
    console.log('Clearing error from state.'); // Log error clearing
    set({ error: null });
  },
}));

export default useAuthStore;
