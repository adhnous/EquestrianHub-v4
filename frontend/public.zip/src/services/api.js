// src/services/api.js
import axios from 'axios';

// Base URL of your backend API (relative path to leverage Vite's proxy)
const API_URL = '/api';

// Create an Axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
});

// Utility Function: Retrieve the stored authentication token
const getStoredAuthToken = () => localStorage.getItem('token');

// Request Interceptor: Attach the token to every request if available
api.interceptors.request.use(
  (config) => {
    const token = getStoredAuthToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    console.log('Request Configuration:', config); // Debugging: Log request configuration
    return config;
  },
  (error) => {
    console.error('Request Error:', error); // Debugging: Log request error
    return Promise.reject(error);
  }
);

// Response Interceptor: Handle unauthorized errors globally
api.interceptors.response.use(
  (response) => {
    console.log('Response:', {
      url: response.config.url,
      status: response.status,
      data: response.data,
    });
    // Return only the `data` object if that's what the app expects
    return response.data;
  },
  (error) => {
    console.error('API Error:', {
      url: error.config?.url,
      status: error.response?.status,
      message: error.response?.data?.message || error.message,
      data: error.response?.data,
    });
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login'; // Redirect to login on unauthorized
    }
    return Promise.reject(error);
  }
);


// Export the Axios instance and the token retrieval function
export { getStoredAuthToken };
export default api;